368-Final
=========

##Objective
My objective for my website is:

* Web Prescence
* Portfolio

#Content

* About me page
* Writing
* Images
* Desing
* Code

#Attribution

* [Codepen](http://codepen.io)
* 
